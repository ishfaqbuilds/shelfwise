return ($input.first().json.deletes || []).map(d => ({ json: d }));
