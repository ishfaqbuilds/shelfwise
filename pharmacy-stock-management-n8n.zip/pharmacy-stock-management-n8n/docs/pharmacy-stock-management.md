# Pharmacy Stock Management Automation (n8n)

Daily low-stock and expiry alerts sent to the pharmacy owner on Telegram, plus an automatic purchase list in Google Sheets.

**Files you need**

- `pharmacy-stock-alerts.json`: the n8n workflow
- `stock-sheet-template.csv`: sample stock data
- `google-cloud-console.md`: Google service account setup (do that first)

---

## 1. How the workflow works

```
Every Morning 9AM → Read Stock Sheet → Analyze Stock & Build Report
                                          ├→ Send Telegram Alert
                                          └→ Split Purchase List → Save to Purchase List Sheet
```

- **Every Morning 9AM:** starts the workflow daily (Asia/Dhaka time).
- **Read Stock Sheet:** reads all rows from the `Stock` tab.
- **Analyze Stock & Build Report:** finds items where `Quantity ≤ MinStock` and items expiring within 30 days, then builds one message grouped by supplier. If nothing needs attention, the workflow stops quietly.
- **Send Telegram Alert:** sends that message to the owner.
- **Split Purchase List + Save:** adds one dated row per low medicine to the `Purchase List` tab.

To change the expiry warning period, edit `EXPIRY_WARNING_DAYS = 30` at the top of the Analyze node's code.

---

## 2. Google Sheet structure

**Tab 1: `Stock`** (row 1 headers, exact spelling)

| Medicine | Quantity | MinStock | ReorderQty | Supplier | SupplierPhone | ExpiryDate |
|---|---|---|---|---|---|---|
| Napa 500mg | 8 | 20 | 50 | Beximco Rep | 017... | 2027-06-30 |

- `ExpiryDate` must be in **YYYY-MM-DD** format. Other formats are skipped.
- If `ReorderQty` is empty, the order quantity is calculated as `MinStock × 2 − Quantity`.

**Tab 2: `Purchase List`** (row 1 headers only)

`Date, Medicine, Current, MinStock, OrderQty, Supplier, SupplierPhone`

Tab names are case-sensitive, and `Purchase List` includes the space.

---

## 3. One-time setup

### 3.1 Telegram bot

1. In Telegram, open **@BotFather** (blue tick) and tap **Start**.
2. Send `/newbot`.
3. Enter the display name, for example `Pharmacy Stock Alerts`.
4. Enter a username that ends in `bot`, for example `YOUR_BOT_USERNAME`.
5. Copy the **token**. Keep it private and never paste it anywhere except n8n.

One bot serves **all** clients. Each client gets their own private chat with it.

### 3.2 Add the Telegram credential in n8n

1. Open the **Send Telegram Alert** node.
2. Under **Credential**, choose **Create new credential**.
3. Paste the token into **Access Token**, then click **Save**.
4. Look for "Connection tested successfully".

### 3.3 Google credential

Follow `google-cloud-console.md` to create the **Google Service Account API** credential.

### 3.4 Template sheet

1. Create a new Google Sheet in your Gmail.
2. Go to **File → Import → Upload → `stock-sheet-template.csv` → Replace current sheet**, and rename the tab `Stock`.
3. Add a `Purchase List` tab with its headers.
4. Test with the sample rows. Afterwards, delete the medicine rows but **keep the headers**, and name the sheet `TEMPLATE – Stock`.

### 3.5 Import and set up the master workflow

1. In n8n, click **+ → Workflow → ⋯ → Import from File → `pharmacy-stock-alerts.json`**.
2. **Read Stock Sheet:**
   - Authentication: **Service Account**
   - Credential: `n8n-bot`
   - Document **By ID**: paste the sheet ID (from the URL, between `/d/` and `/edit`)
   - Sheet: `Stock`
3. **Save to Purchase List Sheet:** use the same credential and sheet ID, set Sheet to `Purchase List`, and set **Mapping Column Mode → Map Automatically**. The import doesn't keep this setting, so set it every time.
4. **Send Telegram Alert:** choose the credential and put the chat ID in **Chat ID**.
5. Press **Ctrl+S**, click **Execute Workflow**, and check that all nodes are green.
6. Click **Publish** to turn on the daily 9AM run.
7. **Download a backup:** go to **⋯ → Download** and keep the JSON file safe.

---

## 4. Per-client onboarding (repeat for every pharmacy)

**A. Sheet (5 min)**

1. Open `TEMPLATE – Stock`, go to **File → Make a copy**, and name it `[Pharmacy] – Stock`.
2. Share it with the **bot email** as Editor.
3. Share it with the **owner's Gmail** as Editor.
4. Copy the **sheet ID**.

**B. Telegram (5 min, on the owner's phone)**

1. Install Telegram.
2. Open `t.me/YOUR_BOT_USERNAME`, tap **Start**, and send `hi`. If you skip this, the bot can't message them.
3. Open **@userinfobot**, tap **Start**, and note the **Id**. That number is the chat ID.

**C. n8n (5 min)**

1. Open the master workflow, go to **⋯ → Duplicate**, and name it `[Pharmacy] – Stock Alerts`.
2. **Read Stock Sheet:** paste the new sheet ID.
3. **Save to Purchase List Sheet:** paste the new sheet ID and check **Map Automatically**.
4. **Send Telegram Alert:** paste the client's chat ID.
5. Click **Execute** and confirm the owner received the message.
6. Click **Publish**.

The credentials stay the same for every client. Never change them.

**D. Records**

1. Enter their real medicines and stock into the sheet.
2. Add them to your client list with: name, phone, sheet ID, chat ID, start date, and paid until.

---

## 5. Pausing or removing a client

- **Pause** (for example, unpaid): open their workflow and click **Unpublish**. Turn it back on with **Publish**.
- **Remove completely:** unpublish and delete the workflow, then remove the bot email from their sheet.
- **Never take away the client's own access** to their sheet. Their data is theirs.

---

## 6. Telegram bot management (BotFather commands)

| Task | Command |
|---|---|
| Get a new token (if leaked) | `/revoke` → pick the bot → update the token in the n8n credential |
| Change display name | `/setname` |
| Change profile photo | `/setuserpic` |
| Change description | `/setdescription` |
| Change "About" text | `/setabouttext` |
| List your bots | `/mybots` |

### Deleting a bot

1. Send `/deletebot` to BotFather.
2. Pick the bot.
3. Type the confirmation sentence exactly as BotFather shows it.

**Warning:** deleting the bot stops alerts for **every** client using it. Before deleting:

1. Create the new bot first (section 3.1).
2. Every client must tap **Start** on the new bot.
3. Update the Telegram credential in n8n with the new token. Check the chat IDs too; they usually stay the same for private chats.
4. Only then delete the old bot.

---

## 7. VPS protection (do once, then check monthly)

1. **Backups:** in Hostinger hPanel, go to **VPS → Backups**, turn on automatic backups, and take a manual snapshot after big changes.
2. **Encryption key:** in the terminal, run
   ```
   docker exec -it $(docker ps --filter "name=n8n" -q | head -1) cat /home/node/.n8n/config
   ```
   Save the `encryptionKey` value in a password manager. If you lose it, all saved credentials become unreadable.
3. **Workflow backup:** go to **⋯ → Download** after every change.

---

## 8. Troubleshooting

| Error | Cause | Fix |
|---|---|---|
| `chat not found` | Owner didn't tap Start, or the chat ID is wrong | Owner taps **Start** on the bot. Use the Id from @userinfobot, **not** the number at the start of the bot token. |
| `can't parse entities` | A `<`, `>` or `&` in the message text | Remove or replace those characters in the Analyze node's code. |
| `At least one value has to be added under 'Values to Send'` | Mapping is set to manual | In **Save to Purchase List Sheet**, set **Mapping Column Mode → Map Automatically**. |
| Sheets "not found" or "permission denied" | Sheet not shared with the bot | Share the sheet with the bot email as **Editor**. |
| Expiry items missing | Wrong date format | Use **YYYY-MM-DD**. |
| No message, but no error | Nothing low or expiring | That's normal. The workflow stops quietly. |
| Alert didn't arrive at 9AM | Workflow not published | Click **Publish**, and check the **Executions** tab. |

---

## 9. Security rules

- The **bot token** and **private key** go **only** into n8n. If you need help, share screenshots with the secrets covered.
- **Token leaked:** send `/revoke` to BotFather. **Key leaked:** delete it in Google Cloud and create a new one.
- Keep the n8n encryption key in a password manager.
